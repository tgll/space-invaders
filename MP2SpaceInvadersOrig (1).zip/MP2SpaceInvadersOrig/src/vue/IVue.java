package vue;

public interface IVue {
	public void dessiner();
}
