package modele;

public interface IMobile {
	public void deplacer();
	public Position getPosition();
}
